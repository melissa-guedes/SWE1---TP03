1. Execute database.sql no MySQL.
2. Adicione mysql-connector-j.jar em WebContent/WEB-INF/lib.
3. Usuário do banco: root
4. Senha do banco: 1234
5. Execute no Tomcat 9.