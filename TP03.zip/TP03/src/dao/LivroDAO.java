//Melissa Escarmeloto Guedes CB3030296 e João Victor Gomes Sinopoli CB3032094

package dao;
import java.sql.*;import java.util.*;import model.Livro;
public class LivroDAO {
String jdbcURL="jdbc:mysql://localhost:3306/crud_livros";String jdbcUsername="root";String jdbcPassword="";
protected Connection getConnection(){Connection c=null;try{Class.forName("com.mysql.cj.jdbc.Driver");c=DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword);}catch(Exception e){e.printStackTrace();}return c;}
public void insertLivro(Livro l){try(Connection c=getConnection();PreparedStatement ps=c.prepareStatement("INSERT INTO livros (titulo,autor,preco) VALUES (?,?,?)")){ps.setString(1,l.getTitulo());ps.setString(2,l.getAutor());ps.setDouble(3,l.getPreco());ps.executeUpdate();}catch(Exception e){e.printStackTrace();}}
public List<Livro> selectAllLivros(){List<Livro> livros=new ArrayList<>();try(Connection c=getConnection();PreparedStatement ps=c.prepareStatement("SELECT * FROM livros")){ResultSet rs=ps.executeQuery();while(rs.next()){livros.add(new Livro(rs.getInt("id"),rs.getString("titulo"),rs.getString("autor"),rs.getDouble("preco")));}}catch(Exception e){e.printStackTrace();}return livros;}
public Livro selectLivro(int id){Livro livro=null;try(Connection c=getConnection();PreparedStatement ps=c.prepareStatement("SELECT * FROM livros WHERE id=?")){ps.setInt(1,id);ResultSet rs=ps.executeQuery();while(rs.next()){livro=new Livro(id,rs.getString("titulo"),rs.getString("autor"),rs.getDouble("preco"));}}catch(Exception e){e.printStackTrace();}return livro;}
public boolean updateLivro(Livro l){boolean row=false;try(Connection c=getConnection();PreparedStatement ps=c.prepareStatement("UPDATE livros SET titulo=?,autor=?,preco=? WHERE id=?")){ps.setString(1,l.getTitulo());ps.setString(2,l.getAutor());ps.setDouble(3,l.getPreco());ps.setInt(4,l.getId());row=ps.executeUpdate()>0;}catch(Exception e){e.printStackTrace();}return row;}
public boolean deleteLivro(int id){boolean row=false;try(Connection c=getConnection();PreparedStatement ps=c.prepareStatement("DELETE FROM livros WHERE id=?")){ps.setInt(1,id);row=ps.executeUpdate()>0;}catch(Exception e){e.printStackTrace();}return row;}
}